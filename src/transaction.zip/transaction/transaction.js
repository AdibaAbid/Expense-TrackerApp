getUser()
getMonthAndYear()

function getUser() {
    const user = JSON.parse(localStorage.getItem('user'))
    console.log("user", user)
    const userElement = document.getElementById("user")
    userElement.innerHTML = user.name

}

function getMonthAndYear() {
    const dateToday = new Date()
    const currentMonth = dateToday.getMonth()
    const CurrentYear = dateToday.getFullYear()
    console.log(dateToday)
    console.log(currentMonth)

    const yearElement = document.getElementById("year")
    yearElement.value = CurrentYear
    const monthElement = document.getElementById("month")
    monthElement.value = currentMonth

}